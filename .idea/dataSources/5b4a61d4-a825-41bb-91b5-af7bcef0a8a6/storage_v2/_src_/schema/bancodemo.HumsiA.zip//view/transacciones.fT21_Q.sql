create view transacciones as
  select
    `c`.`numeroCuenta`      AS `numeroCuenta`,
    `t`.`fecha`             AS `fecha`,
    `t`.`nombreTransaccion` AS `nombreTransaccion`,
    `t`.`monto`             AS `monto`
  from (`bancodemo`.`transaccion` `t`
    join `bancodemo`.`cuenta` `c` on ((`c`.`idcuenta` = `t`.`cuenta_receptor`)))
  group by `t`.`fecha` desc;

