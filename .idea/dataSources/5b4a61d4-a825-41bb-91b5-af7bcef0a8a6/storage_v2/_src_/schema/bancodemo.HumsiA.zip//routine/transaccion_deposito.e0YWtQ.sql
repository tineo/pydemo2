create procedure transaccion_deposito(IN remitente int, IN receptor int, IN monto double, IN nombreT varchar(15),
                                      IN tipo      int)
  BEGIN
	
    insert into transaccion(monto, fecha, nombreTransaccion,tipo,cuenta_remitente, cuenta_receptor)
		values(monto,now(),nombreT,tipo,remitente,receptor);
    update cuenta
    set cuenta.monto = cuenta.monto-monto
    where cuenta.idcuenta=remitente;
	update cuenta
    set cuenta.monto = cuenta.monto+monto
    where cuenta.idcuenta=receptor;
	
END;

